import React from "react";
import TodoListFC from "./components/Todo List FunctionalComponent/TodoListFC";


const App = () => {
  return (
    <React.Fragment>
      <TodoListFC />
    
    </React.Fragment>
  );
};

export default App;
